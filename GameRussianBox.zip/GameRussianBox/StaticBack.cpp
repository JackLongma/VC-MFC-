// StaticBack.cpp : implementation file
//

#include "stdafx.h"
#include "GameRussianBox.h"
#include "StaticBack.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStaticBack

CStaticBack::CStaticBack()
{
}

CStaticBack::~CStaticBack()
{
}


BEGIN_MESSAGE_MAP(CStaticBack, CStatic)
	//{{AFX_MSG_MAP(CStaticBack)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStaticBack message handlers

void CStaticBack::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
     




}
