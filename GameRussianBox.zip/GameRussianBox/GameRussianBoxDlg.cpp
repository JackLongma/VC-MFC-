

#include "stdafx.h"
#include "GameRussianBox.h"
#include "GameRussianBoxDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
		//ON_WM_INTRODUCE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGameRussianBoxDlg dialog

CGameRussianBoxDlg::CGameRussianBoxDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGameRussianBoxDlg::IDD, pParent)
{
	isStarted =false;
Speed=500;
//	m_Volumn=300;
	width=20;
	FallTimes=0;
	m_left=false;
	m_right=false;
	gameState=preStart;
	Score=1000;
	m_backMusic=false;
	m_PressMusic=true;
	//{{AFX_DATA_INIT(CGameRussianBoxDlg)
	m_Width = _T("");
	m_Time = _T("");
	m_Height = _T("");
	m_boxWidth = 0;
	m_boxwei = 0;
	m_Score = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
memset(BackGroundNumbers,0,sizeof(BackGroundNumbers));
//int temp[19]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
//memcpy(BackGroundNumbers[28],temp,sizeof(temp));
for(int i=0;i<19;i++)
{
//	BackGroundNumbers[7][i]=1;
	BackGroundNumbers[27][i]=1;
	BackGroundNumbers[28][i]=1;
}
int box1[MAX_C][5][5] = { /*MAX_C(7)��Ԥ����ĺ���*/
{
{0,0,0,0,0},
{0,0,0,0,0},
{1,1,1,1,0},
{0,0,0,0,0},
{0,0,0,0,0}
},
{
{0,0,0,0,0},
{0,0,1,0,0},
{0,1,1,1,0},
{0,0,0,0,0},
{0,0,0,0,0}
},
{
{0,0,0,0,0},
{0,1,1,0,0},
{0,0,1,1,0},
{0,0,0,0,0},
{0,0,0,0,0}
},

{
{0,0,0,0,0},
{0,0,1,1,0},
{0,1,1,0,0},
{0,0,0,0,0},
{0,0,0,0,0}
},
{
{0,0,0,0,0},
{0,1,1,0,0},
{0,0,1,0,0},
{0,0,1,0,0},
{0,0,0,0,0}
},
{
{0,0,0,0,0},
{0,0,1,1,0},
{0,0,1,0,0},
{0,0,1,0,0},
{0,0,0,0,0}
},
{
{0,0,0,0,0},
{0,0,1,1,0},
{0,0,1,1,0},
{0,0,0,0,0},
{0,0,0,0,0}
}
};
	memcpy(box,box1,sizeof(box1));//��ʼ��7��box��ʽ
	//
	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
}

void CGameRussianBoxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGameRussianBoxDlg)
	DDX_Text(pDX, IDC_EDIT_Time, m_Time);
	DDX_Text(pDX, IDC_EDIT_boxwei, m_boxwei);
	DDX_Text(pDX, IDC_EDIT_Score, m_Score);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGameRussianBoxDlg, CDialog)
	//{{AFX_MSG_MAP(CGameRussianBoxDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_GameStart, OnBUTTONGameStart)
	ON_BN_CLICKED(IDC_BUTTON_GameStop, OnBUTTONGameStop)
	ON_BN_CLICKED(IDC_BUTTON_Change, OnBUTTONChange)
	ON_BN_CLICKED(IDC_BUTTON_pause, OnBUTTONpause)
	ON_BN_CLICKED(IDC_BUTTON_music, OnBUTTONmusic)
	ON_BN_CLICKED(IDC_BUTTON_PressMusic, OnBUTTONPressMusic)
	ON_BN_CLICKED(IDC_RADIO_Fast, OnRADIOFast)
	ON_BN_CLICKED(IDC_RADIO_Mid, OnRADIOMid)
	ON_BN_CLICKED(IDC_RADIO_Slow, OnRADIOSlow)
	ON_COMMAND(ID_MENUITEM_Introduce, OnIntroduceClk)  
	ON_COMMAND(IDR_MENU1_Happy,OnHappyNewYear)
	ON_COMMAND(IDR_MENU1_Press,OnBUTTONPressMusic)
	ON_COMMAND(IDR_MENU1_Back,OnBUTTONmusic)
	ON_WM_DRAWITEM()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CGameRussianBoxDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
///======================
/*	this->SetFocus();
    this->SetForegroundWindow();
    this->SetActiveWindow ();*/
     pMenu=new CMenu();
	 pMenu->LoadMenu(IDR_MENU1);
	 SetMenu(pMenu);
	 CRect dlgtemp(0,0,650,750);
	 CWnd::SetWindowPos(NULL,0,0,dlgtemp.Width(),dlgtemp.Height(),SWP_NOZORDER|SWP_NOMOVE);
	 dlgRect=dlgtemp;
	 /////============
	 ///�����ؼ�λ��
	 GetDlgItem(IDC_STATIC_NextPic)->MoveWindow(dlgRect.right-230,dlgRect.top+80,54,20,TRUE);
	  GetDlgItem(IDC_BUTTON_GameStart)->MoveWindow(dlgRect.right-160,dlgRect.top+210,80,24,TRUE);
	   GetDlgItem(IDC_BUTTON_pause)->MoveWindow(dlgRect.right-160,dlgRect.top+250,80,24,TRUE);
	   GetDlgItem(IDC_BUTTON_GameStop)->MoveWindow(dlgRect.right-160,dlgRect.top+290,80,24,TRUE);
	   GetDlgItem(IDC_BUTTON_Change)->MoveWindow(dlgRect.right-160,dlgRect.top+330,80,24,TRUE);
	   GetDlgItem(IDC_BUTTON_music)->MoveWindow(dlgRect.right-160,dlgRect.top+370,80,24,TRUE);
	   GetDlgItem(IDC_BUTTON_PressMusic)->MoveWindow(dlgRect.right-160,dlgRect.top+410,80,24,TRUE);
	  GetDlgItem(IDC_STATIC_Speed)->MoveWindow(dlgRect.right-160,dlgRect.top+470,110,130,TRUE);
	   GetDlgItem(IDC_RADIO_Fast)->MoveWindow(dlgRect.right-145,dlgRect.top+490,70,20,TRUE);
	   GetDlgItem(IDC_RADIO_Mid)->MoveWindow(dlgRect.right-145,dlgRect.top+530,70,20,TRUE);
	   GetDlgItem(IDC_RADIO_Slow)->MoveWindow(dlgRect.right-145,dlgRect.top+570,70,20,TRUE);
	  ((CButton *)GetDlgItem(IDC_RADIO_Mid))->SetCheck(TRUE); //ѡ��
		   
	 //GetDlgItem()
	 BackTop=120;
	 BackLeft=40;
	 BackWidth=380;
	 BackHeight=580;
	 BoxShowLeft=BackLeft+width*7;
	 BoxShowTop=BackTop;
	CDC* pDC=GetDC();
	CRect rcBack=CRect(BackLeft,BackTop,BackLeft+BackWidth,BackTop+BackHeight);
	pDC->FillSolidRect(&rcBack,RGB(125,125,0));
	CRect rcLeft=CRect(BackLeft-30,BackTop,BackLeft,BackTop+BackHeight);
	pDC->FillSolidRect(&rcLeft,RGB(0,255,0));
	Invalidate(TRUE);
	ReleaseDC(pDC);
	CString strWidth,strHeight;
	strWidth.Format("%d",rcBack.Width());
	strHeight.Format("%d",rcBack.Height());
	m_Width=strWidth;
	m_Height=strHeight;
	CString strtime;
	CTime tm=CTime::GetCurrentTime();
	strtime=tm.Format("%Y-%m-%d-%X");
	m_Time=strtime;
	UpdateData(FALSE);
	PaintNextBack();
				//�޸Ŀ�ʼ��ť�ķ��
   GetDlgItem(IDC_BUTTON_GameStart)->ModifyStyle(0,BS_OWNERDRAW,0);
GetDlgItem(IDC_BUTTON_pause)->ModifyStyle(0,BS_OWNERDRAW,0);
GetDlgItem(IDC_BUTTON_GameStop)->ModifyStyle(0,BS_OWNERDRAW,0);
GetDlgItem(IDC_BUTTON_music)->ModifyStyle(0,BS_OWNERDRAW,0);
//�󶨿ؼ�IDC_BUTTON1����CMyButton����Ӧ���غ���DrawItem()
btnStart.Attach(IDC_BUTTON_GameStart,this);
//����Button Down�ı���ɫ
btnStart.SetDownColor(RGB(255,0,0));
//����Button Up�ı���ɫ
btnStart.SetUpColor(RGB(0,240,255));

////====================
btnPause.Attach(IDC_BUTTON_pause,this);
//����Button Down�ı���ɫ
btnPause.SetDownColor(RGB(155,230,0));
//����Button Up�ı���ɫ
btnPause.SetUpColor(RGB(230,0,255));
///IDC_BUTTON_music
btnBackMusic.Attach(IDC_BUTTON_music,this);
//����Button Down�ı���ɫ
btnBackMusic.SetDownColor(RGB(155,230,0));
//����Button Up�ı���ɫ
if(m_backMusic==true)
{
btnBackMusic.SetUpColor(RGB(230,0,0));
}
else
{
	btnBackMusic.SetUpColor(RGB(0,200,5));
}

//PS��������Ӵ���ʱ��m_cbBtn.Attach(IDC_BUTTON1,this);�������жϣ����ܵ�ԭ����IDC_BUTTON1�ؼ��Ѿ�����һ����Ϣ�������ٴΰ󶨵�Ȼ���ɹ�����
//��������Ϊ����ӳ�亯��DoDataExchange������
//DDX_Control(pDX, IDC_BUTTON1, m_cbBtn);//���ע�͵��Ϳ����ˡ�
////=======
btnStop.Attach(IDC_BUTTON_GameStop,this);
btnStop.SetDownColor(RGB(255,0,0));
//����Button Up�ı���ɫ
btnStop.SetUpColor(RGB(250,0,35));
           m_Score=Score;
			UpdateData(false);

GetDlgItem(IDC_STATIC)->SetFocus();
 PaintNextBack();

	return FALSE; //һ��ֻ��Ҫreturn true���������Ҫ�Լ��趨�ؼ���focus��return false 
	// return TRUE  unless you set the focus to a control
}
void CGameRussianBoxDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}
void CGameRussianBoxDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
      PaintBackGround(BackGroundNumbers,29,19,BackLeft,BackTop,20);
	  PaintNextBack();
	  //PaintSides();
}
HCURSOR CGameRussianBoxDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

HBRUSH CGameRussianBoxDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
    if(nCtlColor==CTLCOLOR_EDIT)
	{
        pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(250,0,0));
		pDC->SetBkColor(RGB(150,40,20));
		HBRUSH b=CreateSolidBrush(RGB(190,190,10));
		return b;
 
	}
	/*if(nCtlColor==CTLCOLOR_BTN)
	{
        pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(255,0,0));
		pDC->SetBkColor(RGB(20,0,20));
		//HBRUSH b=CreateSolidBrush(RGB(190,190,10));
		return hbr;
 
	}*/
	else if(nCtlColor==CTLCOLOR_STATIC)//��̬�ı�
	{
        pDC->SetTextColor(RGB(255,255,255));
	pDC->SetBkColor(RGB(200,100,90));
	HBRUSH b=CreateSolidBrush(RGB(200,140,70));
	return b;
	}
	if(pWnd->GetDlgCtrlID()==IDC_STATIC_NextPic)
	{
        pDC->SetTextColor(RGB(255,0,0));  //����������ɫ
       //pDC->SetBkMode(TRANSPARENT); //�������屳��Ϊ͸��
       return (HBRUSH)::GetStockObject(BLACK_BRUSH);  // ���ñ���ɫ
	}

	return hbr;
}

void CGameRussianBoxDlg::OnTimer(UINT nIDEvent) 
{
	switch (nIDEvent)
	{
			case 1:
			{	
				PaintNextPic(boxNext);
				PaintBackGround(BackGroundNumbers,29,19,BackLeft,BackTop,width);
				PaintByNumbers(boxNow,5,5,BoxShowLeft,BoxShowTop,width);
			//	PaintSides();
	            int touch= CheckTouch(boxNow,BackGroundNumbers,BoxShowLeft,BoxShowTop);
				if (touch==1)
				{
					//������׵�ʱ����߶�
					if(BoxShowTop<BackTop+20)
					{
					 OnBUTTONGameStop();
					 break;
					}

			
				 int backI=(BoxShowTop-BackTop)/width;
				 int backJ=(BoxShowLeft-BackLeft)/width;
				 for(int i=0;i<5;i++)
				 {
					 for(int j=0;j<5;j++)
						 if(boxNow[i][j]==1)
						 {
							 BackGroundNumbers[backI+i][backJ+j]=boxNow[i][j];	 
						 }
				 }
				 CheckLine(BackGroundNumbers);
				 memcpy(boxNow,boxNext,sizeof(boxNow));
				 memcpy(boxNext,box[rand()%7],sizeof(boxNext));
				 BoxShowLeft=BackLeft+width*7;
				 BoxShowTop=120;

				 break;
				}
				BoxShowTop+=20;
				CString str;
				CTime tm=CTime::GetCurrentTime();
				str=tm.Format("%Y-%m-%d-%X");
				m_Time=str;
				m_Score=Score;
				UpdateData(FALSE);
			    break;
			}
			case 2:
			{
			//	PlaySound(MAKEINTRESOURCE(IDR_WAVE6), GetModuleHandle(0), SND_RESOURCE | SND_ASYNC | SND_LOOP);
			break;
			}
	}
	CDialog::OnTimer(nIDEvent);
}

void CGameRussianBoxDlg::OnBUTTONGameStart() 
{
  if(gameState==preStart||gameState==Over)
  {
	 BoxShowLeft=BackLeft+width*7;
	 BoxShowTop=BackTop;
	memcpy(boxNow,box[rand()%7],sizeof(boxNow));
	memcpy(boxNext,box[rand()%7],sizeof(boxNext));
	gameState=Processing;

  }

  if(gameState==Paused)
  {
	  gameState=Processing;
  }
    	SetTimer(1,Speed,NULL);
}

void CGameRussianBoxDlg::OnBUTTONGameStop() 
{
     	if(gameState==Processing||gameState==Paused)
		{
			gameState=Over;
				KillTimer(1);
				CString scoreStr;
				scoreStr.Format("������Ϸ�������ܵ÷�Ϊ:%d����",Score);
				Score=1000;//����
				for(int i=0;i<27;i++)
				memset(BackGroundNumbers[i],0,sizeof(BackGroundNumbers[i]));
				//MessageBox(scoreStr);
				MessageBox(scoreStr,"���շ�������",MB_ICONINFORMATION);
		}
     
		
	//������������ʱ����������
	
}

void CGameRussianBoxDlg::PaintByNumbers(int number[5][5],int rows,int cols,int paintLeft,int paintTop,int width)
{
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{   
			
            int Left=paintLeft+j*width;
			int Top=paintTop+i*width;
			int backi=(Top-BackTop)/width;
			int backj=(Left-BackLeft)/width;
			CDC *pDC=GetDC();
		 CDC memDC;//����һ���豸������

     memDC.CreateCompatibleDC(pDC);//�������ݵ��豸������

     CBitmap bmp;//����λͼ����
   /*  int index=rand()%3;
	 if(index==0)
	 
     bmp.LoadBitmap(IDB_BITMAP2);
	 if(index==1)
		 bmp.LoadBitmap(IDB_BITMAP3);
	 if(index==2)
		 bmp.LoadBitmap(IDB_BITMAP4);*/
	 bmp.LoadBitmap(IDB_BITMAP1);
	 //����λͼ

     memDC.SelectObject(&bmp);//ѡ��λͼ����

     //pDC->BitBlt(30,20,180,180,&memDC,1,1,SRCCOPY);//����λͼ
			CRect rcpaint=CRect(Left,Top,Left+width,Top+width);
				if(number[i][j]==0)
				{
				    //�����ֵ��0����Ҫ���ʲôҲ����
					//pDC->FillSolidRect(&rcpaint,RGB(125,0,0));
				}
				else
				{
					if(BackTop+27*width<=Top)
					{
						pDC->FillSolidRect(&rcpaint,RGB(0,0,0));
					}
					else
					pDC->BitBlt(rcpaint.left,rcpaint.top,width,width,&memDC,1,1,SRCCOPY);//����λͼ
			    //pDC->FillSolidRect(&rcpaint,RGB(0,255,0));
				}
			ReleaseDC(pDC);
		}
	}
}

void CGameRussianBoxDlg::PaintBackGround(int Number[29][19],int rows,int cols,int paintLeft,int paintTop,int width)
{
                  CDC *pDC=GetDC();
		           CRect rect;
				   	
		 CDC memDC;//����һ���豸������

     memDC.CreateCompatibleDC(pDC);//�������ݵ��豸������

     CBitmap bmp;//����λͼ����

     bmp.LoadBitmap(IDB_BITMAP1);//����λͼ

     memDC.SelectObject(&bmp);//ѡ��λͼ����
	/*CRect rcLeft=CRect(BackLeft-40,BackTop,BackLeft,BackTop+BackHeight);
	pDC->FillSolidRect(&rcLeft,RGB(0,125,0));*/
	   for(int i=0;i<rows;i++)
	   {
		   for(int j=0;j<cols;j++)
				{
	
				int top=paintTop+i*width;
				int left=paintLeft+j*width;
                 rect=CRect(left,top,left+width,top+width);
                  if(Number[i][j]==0)
		          	 pDC->FillSolidRect(&rect,RGB(125,0,0));
		          if(Number[i][j]==1)
				  {
					  if(i>=27)//���������������Ϳ�ɺ�ɫ����
                      pDC->FillSolidRect(&rect,RGB(0,0,0));
					  else
						  //pDC->FillSolidRect(&rect,RGB(0,255,0)); 
						  	pDC->BitBlt(rect.left,rect.top,width,width,&memDC,1,1,SRCCOPY);//����λͼ
				  }
				}
	   }
				ReleaseDC(pDC);
}
//boxNow,BackGroundNumbers,BoxShowLeft,BoxShowTop
int CGameRussianBoxDlg::CheckTouch(int BoxNumber[5][5],int BackNumber[29][19],int left,int top)
{ 
	
    for(int i=4;i>=0;i--)
	{
		for(int j=4;j>=0;j--)
		{
		   if(BoxNumber[i][j]==1)
		   {
                int checkPointleft=left+j*width;
				int checkPointtop=top+i*width+width;
				//����checkpointleft ��checkpointtop�ҵ�backnumber�����ֵ
                  int backj=(checkPointleft-BackLeft)/width;
				  int backi=(checkPointtop-BackTop)/width;
				  m_boxwei=backi;
				  UpdateData(false);
				 if(BackNumber[backi][backj]==1)
				 {
					 return 1;
				 }	  
		   }
		}
	}
	return 0;
}

void CGameRussianBoxDlg::OnBUTTONChange() 
{
	// TODO: Add your control notification handler code here
	if(gameState==Processing)
	{ 
		bool canchange=CanChange(BoxShowLeft,BoxShowTop);
		

		
			if(canchange)
			{
				int xxx[5][5];
				for(int i=0;i<5;i++)
				{
					for(int j=0;j<5;j++)
					{
						xxx[i][j]=boxNow[5-1-j][i];
					}
				}
				memcpy(boxNow,xxx,sizeof(boxNow));
					
				if(m_PressMusic==true)
				{
					PlaySound(MAKEINTRESOURCE(IDR_WAVE1),AfxGetResourceHandle(),SND_ASYNC|SND_RESOURCE|SND_NODEFAULT);
				}
			
			}
	}
}

BOOL CGameRussianBoxDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
		if(pMsg->message==WM_KEYDOWN&&(pMsg->wParam==VK_LEFT||pMsg->wParam==VK_RIGHT||pMsg->wParam==VK_UP||pMsg->wParam==VK_DOWN))
	{
	
		return false;
	}
			if(pMsg->message==WM_KEYUP&&(pMsg->wParam==VK_LEFT||pMsg->wParam==VK_RIGHT||pMsg->wParam==VK_UP||pMsg->wParam==VK_DOWN))
	{
	
		return false;
	}
	if(pMsg->message==WM_KEYDOWN&&(pMsg->wParam=='A'||pMsg->wParam=='a'))
	{
		//MessageBox("left");
		if(m_left==false)
		{
			m_left=true;
			if(!OutSides(BoxShowLeft-20,BoxShowTop,boxNow)&&MoveSides(boxNow,BoxShowLeft-20,BoxShowTop)==1)
						 BoxShowLeft-=20;
			}
		return true;
	}
	if(pMsg->message==WM_KEYUP&&(pMsg->wParam=='A'||pMsg->wParam=='a'))
	{
        m_left=false;
		return true;
	}
	
	if(pMsg->message==WM_KEYDOWN&&(pMsg->wParam=='d'||pMsg->wParam=='D'))
	{
		if(m_right==false)
		{
			m_right=true;
	       		if(!OutSides(BoxShowLeft+20,BoxShowTop,boxNow)&&MoveSides(boxNow,BoxShowLeft+20,BoxShowTop)==1)
						 BoxShowLeft+=20;
			
		}
		return true;
	}
	if(pMsg->message==WM_KEYUP&&(pMsg->wParam=='d'||pMsg->wParam=='D'))
	{
		m_right=false;
		return true;
	}

	///
	if(pMsg->message==WM_CHAR&&(pMsg->wParam=='w'||pMsg->wParam=='W'))
	{
		//MessageBox("up");
		OnBUTTONChange();
		return true;

	}
/*	if(pMsg->message==WM_KEYDOWN&&(pMsg->wParam==VK_UP))
	{
	MessageBox("UP");
	}*/
	return CDialog::PreTranslateMessage(pMsg);
}

int CGameRussianBoxDlg::MoveSides(int boxNumber[5][5],int boxLeft,int boxTop)
{
	for(int j=0;j<4;j++)
	{
        for(int i=0;i<4;i++)
		{
              if(boxNumber[i][j]==1)
			  {
                  /*if(boxLeft+width*j<=BackLeft)
					  return 0;*/
				  int backi=(boxTop+i*width-BackTop)/width;

                  int backj=(boxLeft+j*width-BackLeft)/width;//����ʱ�Ƿ��back�г�ͻ�Ƿ���ͼ��
				  if(BackGroundNumbers[backi][backj]==1)
					  return 0;
			  } 
		}

	}




 
	   return 1;
}


//DEL int CGameRussianBoxDlg::MoveSidesRight(int boxNumber[5][5],int boxLeft,int boxTop)
//DEL {
//DEL 	for(int i=4;i>=0;i--)
//DEL 	{
//DEL         for(int j=4;j>=0;j--)
//DEL 		{
//DEL               if(boxNumber[i][j]==1)
//DEL 			  {
//DEL                   if(boxLeft+width*j+width>=BackLeft+BackWidth)
//DEL 					  return 0;
//DEL                    int backi=(boxTop+i*width-BackTop)/width;
//DEL                   int backj=(boxLeft+j*width-BackLeft)/width;
//DEL 				  if(BackGroundNumbers[backi][backj]==1)
//DEL 					  return 0;
//DEL 			  } 
//DEL 		}
//DEL 
//DEL 	}
//DEL  
//DEL 	   return 1;
//DEL 
//DEL }
void CGameRussianBoxDlg::CheckLine(int BackNumber[29][19])
{
	
	for(int i=0;i<27;i++)
	
	{
		int isline=1;
		for(int j=0;j<19;j++)
		{
			if(BackNumber[i][j]==0)
			{
				isline=0;
			}
		}
		if(isline==1)
		{
			Score+=100;
			
			m_Score=Score;
			UpdateData(false);
			//����һ�����˾ͼӷ�
		   MoveCopy(BackNumber,i);

		}
	}

}

 void CGameRussianBoxDlg::MoveCopy(int BackNumber[29][19],int line)
 {

   for(int x=line;x>0;x--)
 	{
             memcpy(BackNumber[x],BackNumber[x-1],sizeof(BackNumber[x]));

 	}
	memset(BackNumber[0],0,sizeof(BackNumber[0]));
 
 }

void CGameRussianBoxDlg::PaintNextPic(int numbers[5][5])
{
for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{   
			
            int Left=dlgRect.right-160+j*width;
			int Top=dlgRect.top+80+i*width;
			
			 CDC *pDC=GetDC();
			 CDC memDC;//����һ���豸������

			 memDC.CreateCompatibleDC(pDC);//�������ݵ��豸������

			 CBitmap bmp;//����λͼ����

		//	 bmp.LoadBitmap(IDB_BITMAP4);//����λͼ
             bmp.LoadBitmap(IDB_BITMAP1);
			 memDC.SelectObject(&bmp);//ѡ��λͼ����
			CRect rcpaint=CRect(Left,Top,Left+width,Top+width);
				if(numbers[i][j]==1)
					pDC->BitBlt(rcpaint.left,rcpaint.top,width,width,&memDC,1,1,SRCCOPY);//����λͼ
			    else
					
					pDC->FillSolidRect(&rcpaint,RGB(190,180,230));
				
			ReleaseDC(pDC);
		}
	}
}

void CGameRussianBoxDlg::PaintNextBack()
{


			 CDC *pDC=GetDC();
			CRect rcpaint=CRect(dlgRect.right-160,dlgRect.top+80,dlgRect.right-60,dlgRect.top+180);
			pDC->FillSolidRect(&rcpaint,RGB(200,190,240));
			   
				
			ReleaseDC(pDC);
}

void CGameRussianBoxDlg::OnBUTTONpause() 
{
	if(gameState==Processing)
	{
		gameState=Paused;
    	KillTimer(1);
	}
	
}

void CGameRussianBoxDlg::OnBUTTONmusic() 
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here
	//	PlaySound(MAKEINTRESOURCE(IDR_WAVE5),AfxGetResourceHandle(),SND_ASYNC|SND_RESOURCE|SND_NODEFAULT);
if(!m_backMusic)
{
	m_backMusic=true;
	//	PlaySound(MAKEINTRESOURCE(IDR_WAVE5),AfxGetResourceHandle(),SND_ASYNC|SND_RESOURCE|SND_NODEFAULT);
	PlaySound(MAKEINTRESOURCE(IDR_WAVE6), GetModuleHandle(0), SND_RESOURCE | SND_ASYNC | SND_LOOP); //������������ʱ����������	
}
else
{
	m_backMusic=false;
	PlaySound(NULL,NULL,NULL);
}
}

void CGameRussianBoxDlg::OnBUTTONPressMusic() 
{
	if(m_PressMusic==false)
		m_PressMusic=true;
	else
		m_PressMusic=false;
	
}

void CGameRussianBoxDlg::OnIntroduceClk()
{
CIntrodlg  *pDlg=new CIntrodlg;
 pDlg->Create(IDD_DIALOG_Introduce,this);
 pDlg->ShowWindow(SW_SHOW);
}

void CGameRussianBoxDlg::OnRADIOFast() 
{
	// TODO: Add your control notification handler code here
	Speed=200;
	((CButton *)GetDlgItem(IDC_RADIO_Fast))->SetCheck(TRUE); //ѡ��
	GetDlgItem(IDC_STATIC)->SetFocus();
	if(gameState==Processing)
	OnBUTTONGameStart() ;
}

void CGameRussianBoxDlg::OnRADIOMid() 
{
	// TODO: Add your control notification handler code here
	Speed=500;	
	((CButton *)GetDlgItem(IDC_RADIO_Mid))->SetCheck(TRUE); //ѡ��
	GetDlgItem(IDC_STATIC)->SetFocus();
	if(gameState==Processing)
	OnBUTTONGameStart() ;
}

void CGameRussianBoxDlg::OnRADIOSlow() 
{
	// TODO: Add your control notification handler code here
	Speed=1000;
	((CButton *)GetDlgItem(IDC_RADIO_Slow))->SetCheck(TRUE); //ѡ��
		GetDlgItem(IDC_STATIC)->SetFocus();
		if(gameState==Processing)
		OnBUTTONGameStart() ;
}

//DEL void CGameRussianBoxDlg::OnHappyNewYear()
//DEL {
//DEL 
//DEL }

void CGameRussianBoxDlg::OnHappyNewYear()
{
  MessageBox("��ϲ���ƣ���@_@","�������",MB_ICONINFORMATION);
}

void CGameRussianBoxDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

bool CGameRussianBoxDlg::CanChange(int BoxShowLeft,int BoxShowTop)
{
	
	/*if(BoxShowLeft==BackLeft)
	{
		      int backi=(BoxShowTop+100-BackTop)/width;//���ײ�
              for(int tx=0;tx<5;tx++)
			  {
				  int backj=(BoxShowLeft+width*tx-BackLeft)/width;
                if(BackGroundNumbers[backi][backj]==1)
				  return false;
			  }
			  int backj=(BoxShowLeft+width*5-BackLeft)/width;//j����Ҳ�
			  
			  for(int ty=0;ty<5;ty++)
			  {
				  int backi=(BoxShowTop+ty*width-BackTop)/width;
				  if(BackGroundNumbers[backi][backj]==1)
					  return false;
			  }
	}
	if(BoxShowLeft==BackLeft+BackWidth-width*5)
	{
             int backi=(BoxShowTop+100-BackTop)/width;//���ײ�
              for(int tx=0;tx<5;tx++)
			  {
				  int backj=(BoxShowLeft+width*tx-BackLeft)/width;
                if(BackGroundNumbers[backi][backj]==1)
				  return false;
			  }
                 int backj=(BoxShowLeft+width*5-BackLeft)/width-6;//j�������
			  
			  for(int ty=0;ty<5;ty++)
			  {
				  int backi=(BoxShowTop+ty*width-BackTop)/width;
				  if(BackGroundNumbers[backi][backj]==1)
					  return false;
			  }
           
	}
	else
	{

		int backi=(BoxShowTop+100-BackTop)/width;//���ײ�
              for(int tx=0;tx<5;tx++)
			  {
				  int backj=(BoxShowLeft+width*tx-BackLeft)/width;
                if(BackGroundNumbers[backi][backj]==1)
				  return false;
			  }
			  int backj=(BoxShowLeft+width*5-BackLeft)/width;//j����Ҳ�
			  
			  for(int ty=0;ty<5;ty++)
			  {
				  int backi=(BoxShowTop+ty*width-BackTop)/width;
				  if(BackGroundNumbers[backi][backj]==1)
					  return false;
			  }
			  int backjj=(BoxShowLeft+width*5-BackLeft)/width-6;//j�������
			  
			  for(int tyy=0;tyy<5;tyy++)
			  {
				  int backi=(BoxShowTop+ty*width-BackTop)/width;
				  if(BackGroundNumbers[backi][backjj]==1)
					  return false;
			  }

	}*/
           	    int temp[5][5];
				for(int i=0;i<5;i++)
				{
					for(int j=0;j<5;j++)
					{
						temp[i][j]=boxNow[5-1-j][i];
					}
				}
				//memcpy(boxNow,xxx,sizeof(boxNow));
				if(OutSides(BoxShowLeft,BoxShowTop,temp))//������κ�����returnfalse
					return false;
				if(MoveSides(temp,BoxShowLeft,BoxShowTop)==0)
					return false;



	return true;

}

//DEL void CGameRussianBoxDlg::PaintSides()
//DEL {
//DEL 	         CDC *pDC=GetDC();
//DEL 			CRect rcpaint=CRect(20,120,40,700);
//DEL 			pDC->FillSolidRect(&rcpaint,RGB(10,110,150));
//DEL 			 CRect rcPaintright=CRect(420,120,440,700);  
//DEL 				pDC->FillSolidRect(&rcPaintright,RGB(10,110,150));	
//DEL 			ReleaseDC(pDC);
//DEL }

bool CGameRussianBoxDlg::OutSides(int BoxShowLeft,int BoxShowTop,int boxnumber[5][5])
{//����Ƿ����ҳ��ֳ��磬ע���Ǽ��number=1��λ��

for(int i=0;i<5;i++)
{
	for(int j=0;j<5;j++)
	{
        if( boxnumber[i][j]==1)
		{
              if(BoxShowLeft+j*width<BackLeft)
				  return true;
			  if(BoxShowLeft+j*width+width>BackLeft+BackWidth)
				  return true;

		}
 
	}
}


return false;
}
