// Introdlg.cpp : implementation file
//

#include "stdafx.h"
#include "gamerussianbox.h"
#include "Introdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIntrodlg dialog


CIntrodlg::CIntrodlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIntrodlg::IDD, pParent)
{
	welcome="\r\n          ��ӭ���汾��Ϸ��������֣�\r\n\r\n ��Ϸ����a��A �� d��D ��������\r\n\r\n�����ƶ�����ĸ��w����W�����������\r\n\r\n������!";

}


void CIntrodlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIntrodlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIntrodlg, CDialog)
	//{{AFX_MSG_MAP(CIntrodlg)
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIntrodlg message handlers

void CIntrodlg::OnPaint() 
{
	CPaintDC dc(this);
    

}

BOOL CIntrodlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
GetDlgItem(IDC_EDIT_Introduction)->SetWindowText(welcome);























    GetDlgItem(IDC_STATIC_Welcome)->SetFocus();
	
	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

HBRUSH CIntrodlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	 if(nCtlColor==CTLCOLOR_EDIT)
	{
        pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(250,0,0));
		pDC->SetBkColor(RGB(150,40,20));
		HBRUSH b=CreateSolidBrush(RGB(190,190,10));
		return b;
 
	}
	 	else if(nCtlColor==CTLCOLOR_STATIC)//��̬�ı�
	{
       pDC->SetTextColor(RGB(0,0,0));
	   pDC->SetBkColor(RGB(230,200,200));
	   HBRUSH b=CreateSolidBrush(RGB(230,200,200));
	   return b;
	}
	return hbr;
}
