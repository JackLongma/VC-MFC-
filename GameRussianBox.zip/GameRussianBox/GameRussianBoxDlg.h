// GameRussianBoxDlg.h : header file
//

#define MAX_C 7
 #include <Mmsystem.h> 
#include "resource.h"
#include "MyButton.h"
#include "Introdlg.h"
#pragma comment(lib, "Winmm.lib")  
#if !defined(AFX_GAMERUSSIANBOXDLG_H__4844B7A7_8625_436B_A462_31E6F1229194__INCLUDED_)
#define AFX_GAMERUSSIANBOXDLG_H__4844B7A7_8625_436B_A462_31E6F1229194__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CGameRussianBoxDlg dialog

class CGameRussianBoxDlg : public CDialog
{
public:
	bool OutSides(int BoxShowLeft,int BoxShowTop,int boxnumber[5][5]);
	bool CanChange(int BoxShowLeft,int BoxShowTop);
	void OnHappyNewYear();
	void OnIntroduceClk();

	
//	DWORD m_Volumn;
	bool m_PressMusic;
	bool m_backMusic;
	int Score;
	//ö�� ��Ϸ��ʼǰ�������У���ͣ�У�����
	enum GameState{preStart,Processing,Paused,Over} gameState;
	void PaintNextBack();
	void PaintNextPic(int nubers[5][5]);
	void CheckLine(int BackNumber[29][19]);
	 void MoveCopy(int numbers[29][19],int line);
	CBitmap bitmap;
    bool m_left,m_right;
	int MoveSides(int boxNumber[5][5],int boxLeft,int boxTop);
	int FallTimes;
	int CheckTouch(int BoxNumber[5][5],int BackNumber[29][19],int left,int top);
	void PaintBackGround(int Number[29][19],int rows,int cols,int paintLeft,int paintTop,int width);
	CGameRussianBoxDlg(CWnd* pParent = NULL);	// standard constructor
void PaintByNumbers(int number[5][5],int rows,int cols,int paintLeft,int paintTop,int width);
	//�����ܹ��м���ͼ������
	CRect dlgRect;//������ʼ���ĶԻ����С
	int BackTop,BackLeft,BackWidth,BackHeight;
	int BoxShowLeft,BoxShowTop;
	int box[MAX_C][5][5];
	int BackGroundNumbers[29][19];
	 int boxNow[5][5];
	 int boxChange[5][5];
	 int boxNext[5][5];
	 bool isStarted;
	 int width;
	 CMyButton btnStart,btnPause,btnStop,btnBackMusic;
	 CMenu* pMenu;
	//int box[MAX_C][5][5]=0;
// Dialog Data
	//{{AFX_DATA(CGameRussianBoxDlg)
	enum { IDD = IDD_GAMERUSSIANBOX_DIALOG };
	CString	m_Width;
	CString	m_Time;
	CString	m_Height;
	int		m_boxWidth;
	int		m_boxwei;
	int		m_Score;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGameRussianBoxDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CGameRussianBoxDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBUTTONGameStart();
	afx_msg void OnBUTTONGameStop();
	afx_msg void OnBUTTONChange();
	afx_msg void OnBUTTONpause();
	afx_msg void OnBUTTONmusic();
	afx_msg void OnBUTTONPressMusic();
	afx_msg void OnRADIOFast();
	afx_msg void OnRADIOMid();
	afx_msg void OnRADIOSlow();
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int Speed;
};


#endif // !defined(AFX_GAMERUSSIANBOXDLG_H__4844B7A7_8625_436B_A462_31E6F1229194__INCLUDED_)
