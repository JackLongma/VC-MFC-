//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GameRussianBox.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GAMERUSSIANBOX_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDR_WAVE1                       130
#define IDR_WAVE2                       131
#define IDD_DIALOG_Recommend            132
#define IDI_ICON1                       134
#define IDB_BITMAP2                     135
#define IDB_BITMAP3                     137
#define IDB_BITMAP4                     140
#define IDR_MENU1                       141
#define IDR_WAVE3                       143
#define IDR_WAVE4                       144
#define IDR_WAVE5                       147
#define IDR_WAVE6                       148
#define IDD_DIALOG_Introduce            150
#define IDR_MENU2                       151
#define IDC_EDIT_Score                  1005
#define IDC_EDIT_Time                   1006
#define IDC_EDIT_boxwei                 1009
#define IDC_BUTTON_GameStart            1010
#define IDC_BUTTON_GameStop             1011
#define IDC_BUTTON_Change               1012
#define IDC_BUTTON_music                1013
#define IDC_STATIC_NextPic              1014
#define IDC_BUTTON_pause                1015
#define IDC_BUTTON_Back                 1016
#define IDC_BUTTON_PressMusic           1016
#define IDC_STATIC_score                1018
#define IDC_STATIC_position             1019
#define IDC_EDIT_Introduction           1024
#define IDC_STATIC_Welcome              1025
#define IDC_MONTHCALENDAR1              1027
#define IDC_RADIO_Fast                  1030
#define IDC_RADIO_Mid                   1031
#define IDC_RADIO_Slow                  1032
#define IDC_STATIC_Speed                1033
#define ID_MENUITEM32771                32771
#define ID_MENUITEM_Introduce           32772
#define IDR_MENU2_OPEN                  32773
#define IDR_MENU2_PICTURE               32774
#define IDR_MENU1_Happy                 32782
#define IDR_MENU1_Press                 32783
#define IDR_MENU1_Back                  32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
