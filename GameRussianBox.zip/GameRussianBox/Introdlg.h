#if !defined(AFX_INTRODLG_H__1DC57AF5_78C3_4B38_8C7D_E8BACAE8650D__INCLUDED_)
#define AFX_INTRODLG_H__1DC57AF5_78C3_4B38_8C7D_E8BACAE8650D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Introdlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIntrodlg dialog

class CIntrodlg : public CDialog
{
// Construction
public:
	
	CString welcome;
	CIntrodlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CIntrodlg)
	enum { IDD = IDD_DIALOG_Introduce };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntrodlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIntrodlg)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTRODLG_H__1DC57AF5_78C3_4B38_8C7D_E8BACAE8650D__INCLUDED_)
