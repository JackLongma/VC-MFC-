// GameRussianBox.h : main header file for the GAMERUSSIANBOX application
//

#if !defined(AFX_GAMERUSSIANBOX_H__682513F9_9AB2_4847_8FD7_3411A1987CEA__INCLUDED_)
#define AFX_GAMERUSSIANBOX_H__682513F9_9AB2_4847_8FD7_3411A1987CEA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGameRussianBoxApp:
// See GameRussianBox.cpp for the implementation of this class
//

class CGameRussianBoxApp : public CWinApp
{
public:
	CGameRussianBoxApp();
  
  

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGameRussianBoxApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGameRussianBoxApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GAMERUSSIANBOX_H__682513F9_9AB2_4847_8FD7_3411A1987CEA__INCLUDED_)
